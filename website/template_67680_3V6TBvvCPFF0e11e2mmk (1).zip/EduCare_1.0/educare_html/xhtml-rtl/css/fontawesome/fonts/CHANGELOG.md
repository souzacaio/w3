CHANGE LOG
==========

## 1.0.2 (2016-01-24)
 - Fix typo

## 1.0.1 (2016-01-24)
 - Duplicate CSS / nested RTL/RTL fa-arrow

## 1.0.0 (2015-05-14)
 - Initial release
